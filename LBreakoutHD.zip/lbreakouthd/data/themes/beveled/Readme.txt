Created by Will Pittenger

Features:
* All maluses have a red border
* All bonuses have either a grey or gold border (the later are point bonuses)
* Solid simple border with gradient around the background
* SVG files are included for all custom images
* Backgrounds are all filter presets or combinations of filter presets from Inkscape 0.48.2
* No swear words (delete the WAV files if you want them back)

Notes:
* Export background images, including menuback.png, from the SVG by opening the cooresponding SVG in Inkscape.  It's export tool will, by default, export to the same folder where the SVG is at.  Be sure nothing is selected when you do that.  The filename is already set.
* All other items are part of Objects.svg.  To export those, open Objects.svg.  Select the object you want to export.  Each png cooresponds to a group in Objects.svg.  When you export the file with Inkscape, it will export to the folder with the SVG using the correct filename.
* I added a f_game.png, but my attempt to create the f_frame.png didn't work well.  You can export it if you want to try it.  I tried a black background, but Inkscape doesn't let you control the amount of anti-aliasing used.  So LBreakout has to deal with colors that aren't quite black (the color it treats as transparent).  Those not-quite black pixels show up in the rendered font.  I tried using no background (PNG supports true transparency), but LBreakout treats that as white.  The current object uses a gray background.  But that doesn't work either.  It almost works for the score, but LBreakout tries to use the same font image in other places with a different background.  I will revisit this when LBreakout support full the PNG alpha channel.
* I had the same problem with warp.png.  For now, I provide a version that uses a background of its own.  But in night mode, this background is wrong.  When LBreakout supports the full PNG alpha channel, I will change the background to be simply fully transparent.
* The indestructable bricks are meant to look like concrete with a steel armor plate.  The version that can be destroyed with the energy ball omits the armor.
* The reflection bricks are meant to look like rubber.
* The bricks that take several hits to destroy are meant to look like they have cracks.  I inadverdantely arranged for some of those cracks to line up.