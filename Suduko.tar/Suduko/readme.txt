Suduko - An SDL implementation

Copyright (C) 2013 Scott McGregor

You may use, distribute or modify all of the code in this zipfile under the terms of the
GNU General Public License as published by the Free Software Foundation.
--------------------------------------------------------------------

To compile this project insure you link against:
Windows:
SDL
SDLmain
SDL_image
SDL_ttf

Linux:
SDL
SDL_ttf
SDL_image
