Puzznic Stage 4 levels 1 to 10.
Tested.
